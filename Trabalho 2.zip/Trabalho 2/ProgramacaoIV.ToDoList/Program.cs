using Microsoft.EntityFrameworkCore;
using ProgramacaoIV.ToDoList.Context;

namespace ProgramacaoIV.ToDoList;

public class Program
{
    private const string _connectionString = "Server=localhost;Port=3306;Database=umfg_notas;Uid=root;Pwd=root;";

    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        builder.Services.AddControllers();

        builder.Services.AddDbContext<NotaContext>(options => options.UseMySQL(_connectionString));

        var app = builder.Build();
        app.MapControllers();

        app.Run();
    }
}
