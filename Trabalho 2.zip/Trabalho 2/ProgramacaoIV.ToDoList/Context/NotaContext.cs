using Microsoft.EntityFrameworkCore;
using ProgramacaoIV.ToDoList.Model;

namespace ProgramacaoIV.ToDoList.Context
{
    public class NotaContext : DbContext
    {
        public DbSet<Nota> Notas { get; set; }

        public NotaContext(DbContextOptions<NotaContext> options) : base(options)
        {
            if (Database.GetPendingMigrations().Any())
                Database.Migrate();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Nota>().HasKey(n => n.Id);
            modelBuilder.Entity<Nota>().Property(n => n.Aluno).IsRequired().HasMaxLength(100);
            modelBuilder.Entity<Nota>().Property(n => n.Disciplina).IsRequired().HasMaxLength(100);
            modelBuilder.Entity<Nota>().Property(n => n.Valor).IsRequired().HasPrecision(3, 2); // Para garantir que seja decimal entre 0 e 10
        }
    }
}
