﻿using System.ComponentModel;

public enum TipoUsuario
{
    [Description("Usuário com permissões administrativas")]
    Administrador,

    [Description("Usuário comum com permissões limitadas")]
    UsuarioComum,

    [Description("Visitante sem permissões de edição")]
    Visitante
}
