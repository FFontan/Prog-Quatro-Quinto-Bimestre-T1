﻿using ProgramacaoIV.Exercicios.Janelas;
using System.Windows;

namespace ProgramacaoIV.Exercicios;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void btnExercicioUm_Click(object sender, RoutedEventArgs e)
    {
        new ExercicioUm().ShowDialog();
    }

    private void btnExercicioDois_Click(object sender, RoutedEventArgs e)
    {
        new Exercicio2().ShowDialog();
    }
    private void btnExercicioTres_Click(object sender, RoutedEventArgs e)
    {
        new Exercicio3().ShowDialog();
    }

    private void btnExercicioQuatro_Click(object sender, RoutedEventArgs e)
    {
        new Exercicio4().ShowDialog();
    }

    private void btnExercicioCinco_Click(object sender, RoutedEventArgs e)
    {
        new Exercicio5().ShowDialog();
    }

    private void btnExercicioSeis_Click(object sender, RoutedEventArgs e)
    {
        new Exercicio6().ShowDialog();
    }

    private void btnExercicioSete_Click(object sender, RoutedEventArgs e)
    {
        new Exercicio7().ShowDialog();
    }

    private void btnExercicioOito_Click(object sender, RoutedEventArgs e)
    {
        new Exercicio8().ShowDialog();
    }

    private void btnExercicioNove_Click(object sender, RoutedEventArgs e)
    {
        new Exercicio9().ShowDialog();
    }

    private void btnExercicioDez_Click(object sender, RoutedEventArgs e)
    {
        new Exercicio10().ShowDialog();
    }
}