﻿using System.Windows;

namespace ProgramacaoIV.Exercicios.Janelas
{
    public partial class Exercicio3 : Window
    {
        public Exercicio3()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, RoutedEventArgs e)
        {
            if (datePickerNascimento.SelectedDate.HasValue)
            {
                DateTime dataNascimento = datePickerNascimento.SelectedDate.Value;
                DateTime dataAtual = DateTime.Today;

                DateTime proximoAniversario = new DateTime(dataAtual.Year, dataNascimento.Month, dataNascimento.Day);

                if (proximoAniversario < dataAtual)
                {
                    proximoAniversario = proximoAniversario.AddYears(1);
                }
                int diasFaltando = (proximoAniversario - dataAtual).Days;

                MessageBox.Show($"Faltam {diasFaltando} dias para o seu próximo aniversário!", "Próximo Aniversário", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Por favor, selecione sua data de nascimento.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
