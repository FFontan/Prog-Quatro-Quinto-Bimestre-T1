﻿using System;
using System.ComponentModel;
using System.Reflection;
using System.Windows;

namespace ProgramacaoIV.Exercicios.Janelas
{
    public partial class Exercicio5 : Window
    {
        public Exercicio5()
        {
            InitializeComponent();

            comboBoxTipoUsuario.ItemsSource = Enum.GetValues(typeof(TipoUsuario));
        }

        private void btnExibirDescricao_Click(object sender, RoutedEventArgs e)
        {
            if (comboBoxTipoUsuario.SelectedItem != null)
            {
                TipoUsuario tipoSelecionado = (TipoUsuario)comboBoxTipoUsuario.SelectedItem;

                string descricao = GetEnumDescription(tipoSelecionado);

                MessageBox.Show(descricao, "Descrição do Tipo de Usuário", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Por favor, selecione um tipo de usuário.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());
            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

            return attributes.Length > 0 ? attributes[0].Description : value.ToString();
        }
    }
}
