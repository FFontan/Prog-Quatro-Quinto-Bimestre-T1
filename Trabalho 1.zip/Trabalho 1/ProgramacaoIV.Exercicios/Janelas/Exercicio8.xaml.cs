﻿using System;
using System.Windows;

namespace ProgramacaoIV.Exercicios.Janelas
{
    public partial class Exercicio8 : Window
    {
        public Exercicio8()
        {
            InitializeComponent();
        }

        private void btnVerificarDia_Click(object sender, RoutedEventArgs e)
        {
            if (datePicker.SelectedDate.HasValue)
            {
                DateTime dataSelecionada = datePicker.SelectedDate.Value;
                DiasDaSemana.EnumDias diaSemana = (DiasDaSemana.EnumDias)(int)dataSelecionada.DayOfWeek;
                MessageBox.Show($"O dia da semana é: {diaSemana}", "Dia da Semana", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Por favor, selecione uma data.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
